//  for(let i = 1; i < 30; i++)
//  {
//      console.log(i);
//  }
//  let dineroEnCaja = Number(prompt("Ingrese el monto de dinero"));
//  let contador = 0;
//  while(dineroEnCaja > 0)
//  {
//      alert("Dinero disponible: "+ dineroEnCaja);
//      let presupuestoProyecto = Number(prompt("Ingrese el monto del proyecto"));
//      if(dineroEnCaja>=presupuestoProyecto )
//      {
//          dineroEnCaja -= presupuestoProyecto;
//          alert("Se asignaron recursos para su proyecto");
//          contador +=1 ;
//      }
//      else{
//          alert("No alcanzan los recursos");
//      }
//  }
//  alert("Se han agotado los recursos");
//  alert("Se aprobaron "+ contador +" proyectos ");







//  let voto; 

//  for(let i = 1; i < 30; i++)
// {
//     voto = prompt("Ingrese el número de su candidato de su preferencia:\n1. Mateo.\n2. Marcos.\n3. Lucas.\n4. Juan.")
//     switch(voto){
//         case "1":
//             candidato1 ++;
//             break;
//         case "2":
//             candidato2 ++;
//             break;
//         case "3":
//             candidato3 ++;
//             break;
//         case "4":
//             candidato4 ++;
//             break;
//    }
// }
// $mensaje = "El vocero del curso es: ";

// alert($mensaje);
const numVoto = document.getElementById("numVoto");
const btnVoto = document.getElementById("btnVoto");
const votoGanador = document.getElementById("votoGanador");

let candidato1 = 0;
let candidato2 = 0;
let candidato3 = 0;
let candidato4 = 0;

function votosCandidatos() 
{
    
    for (let i = 1; i < 30; i++) {
        if (numVoto == "1") {
            candidato1++;
        } else if (numVoto == "2") {
            candidato2++;
        } else if (numVoto == "3") {
            candidato3++;
        } else if (numVoto == "4") {
            candidato4++;
        }
    }
}
function ganadorVotos() {
    if (candidato1 > candidato2 && candidato1 > candidato3 && candidato1 > candidato4) {
        votoGanador.textContent = "Mateo";
    }
    else if (candidato2 > candidato1 && candidato2 > candidato3 && candidato2 > candidato4) {
        votoGanador.textContent = "Marcos"
    }
    else if (candidato3 > candidato1 && candidato3 > candidato2 && candidato3 > candidato4) {
        votoGanador.textContent = "Lucas"
    }
    else if (candidato4 > candidato1 && candidato4 > candidato2 && candidato4 > candidato3) {
        votoGanador.textContent = "Juan"
    }
    else {
        votoGanador.textContent = "No hay ganador"
    }
}

btnVoto.addEventListener("click", votosCandidatos)